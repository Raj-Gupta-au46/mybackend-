const batchName = "Lithium "

let printName = function() {
    console.log('Bathc name is ', batchName)
}

module.exports.name = batchName
module.exports.printName = printName


